package com.fridaevo.android

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ProcessAdapter(
    private var items: List<ProcessItem>,
    private val onItemClick: (ProcessItem) -> Unit
) : RecyclerView.Adapter<ProcessAdapter.VH>() {

    private var filtered: List<ProcessItem> = items

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val icon: ImageView = view.findViewById(R.id.ivProcessIcon)
        val name: TextView = view.findViewById(R.id.tvProcessName)
        val pkg: TextView = view.findViewById(R.id.tvProcessPkg)
        val pid: TextView = view.findViewById(R.id.tvProcessPid)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_process, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = filtered[position]
        holder.name.text = item.name
        holder.pkg.text = item.packageName
        holder.pid.text = if (item.pid > 0) "PID ${item.pid}" else ""
        item.icon?.let { holder.icon.setImageDrawable(it) }
        holder.itemView.setOnClickListener { onItemClick(item) }
    }

    override fun getItemCount() = filtered.size

    fun update(newItems: List<ProcessItem>) {
        items = newItems
        filtered = newItems
        notifyDataSetChanged()
    }

    fun filter(query: String) {
        filtered = if (query.isBlank()) items
        else items.filter {
            it.name.contains(query, ignoreCase = true) ||
            it.packageName.contains(query, ignoreCase = true)
        }
        notifyDataSetChanged()
    }
}
