package com.fridaevo.android

import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

object FridaEngine {

    private val logListeners = mutableListOf<(String) -> Unit>()
    private var engineProcess: Process? = null
    private var injectProcess: Process? = null
    private var isRunning = false
    private var importedScriptCode: String? = null
    private lateinit var appContext: Context

    fun init(context: Context) {
        appContext = context.applicationContext
    }

    // ─── Log system ───────────────────────────────────────────

    fun addLogListener(listener: (String) -> Unit) {
        logListeners.add(listener)
    }

    fun removeLogListener(listener: (String) -> Unit) {
        logListeners.remove(listener)
    }

    fun sendLog(message: String) {
        logListeners.forEach { it(message) }
    }

    // ─── Root check ───────────────────────────────────────────

    suspend fun checkRoot(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "id"))
            val result = p.inputStream.bufferedReader().readText()
            p.waitFor()
            result.contains("uid=0")
        } catch (e: Exception) {
            false
        }
    }

    // ─── Execute root command ─────────────────────────────────

    fun executeRootCommand(cmd: String): String {
        return try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            val out = p.inputStream.bufferedReader().readText()
            val err = p.errorStream.bufferedReader().readText()
            p.waitFor()
            if (err.isNotBlank()) "$out\n[ERR] $err" else out
        } catch (e: Exception) {
            "[ERROR] ${e.message}"
        }
    }

    // ─── Extract f_engine ─────────────────────────────────────

    fun extractEngine(): String {
        val outFile = File(appContext.filesDir, "f_engine")
        if (!outFile.exists()) {
            appContext.assets.open("f_engine").use { input ->
                outFile.outputStream().use { output -> input.copyTo(output) }
            }
        }
        executeRootCommand("chmod 700 ${outFile.absolutePath}")
        return outFile.absolutePath
    }

    // ─── Start frida-server ───────────────────────────────────

    suspend fun startFridaServer(): Boolean = withContext(Dispatchers.IO) {
        return@withContext try {
            val enginePath = extractEngine()
            // Check if already running
            val check = executeRootCommand("pgrep -f f_engine")
            if (check.trim().isNotEmpty()) {
                sendLog("[INFO] frida-server already running (PID ${check.trim()})")
                return@withContext true
            }
            executeRootCommand("$enginePath &")
            Thread.sleep(1500)
            val recheck = executeRootCommand("pgrep -f f_engine")
            recheck.trim().isNotEmpty()
        } catch (e: Exception) {
            sendLog("[ERROR] Failed to start frida-server: ${e.message}")
            false
        }
    }

    // ─── Inject ───────────────────────────────────────────────

    suspend fun startFridaInject(
        packageName: String,
        libName: String,
        spawnMode: Boolean
    ) = withContext(Dispatchers.IO) {
        if (isRunning) {
            sendLog("[WARN] Already injecting, stop first.")
            return@withContext
        }
        sendLog("[INFO] Starting injection → $packageName")
        sendLog("[INFO] Target lib: $libName")

        val serverOk = startFridaServer()
        if (!serverOk) {
            sendLog("[ERROR] Could not start frida-server")
            return@withContext
        }

        isRunning = true

        // Write a minimal default inject script to temp
        val scriptCode = """
            Java.perform(function() {
                send("[EVO] Frida attached to: $packageName");
                send("[EVO] Lib: $libName");
            });
        """.trimIndent()

        val scriptFile = File(appContext.cacheDir, "evo_inject.js")
        scriptFile.writeText(scriptCode)

        val flag = if (spawnMode) "-f" else "-n"
        val cmd = "frida $flag $packageName -l ${scriptFile.absolutePath} -H 127.0.0.1"

        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            injectProcess = p
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            val errReader = BufferedReader(InputStreamReader(p.errorStream))

            // Stream stdout
            var line: String?
            while (reader.readLine().also { line = it } != null && isRunning) {
                sendLog(line ?: "")
            }
            while (errReader.readLine().also { line = it } != null && isRunning) {
                sendLog("[ERR] ${line ?: ""}")
            }
        } catch (e: Exception) {
            sendLog("[ERROR] Inject failed: ${e.message}")
        } finally {
            isRunning = false
            sendLog("[INFO] Inject session ended.")
        }
    }

    // ─── Run custom script ────────────────────────────────────

    suspend fun startFridaScript(
        packageName: String,
        scriptCode: String
    ) = withContext(Dispatchers.IO) {
        if (isRunning) {
            sendLog("[WARN] Already running, stop first.")
            return@withContext
        }
        if (scriptCode.isBlank()) {
            sendLog("[ERROR] Script is empty.")
            return@withContext
        }
        sendLog("[INFO] Running script on $packageName")

        val serverOk = startFridaServer()
        if (!serverOk) {
            sendLog("[ERROR] Could not start frida-server")
            return@withContext
        }

        isRunning = true

        val scriptFile = File(appContext.cacheDir, "evo_script.js")
        scriptFile.writeText(scriptCode)

        val cmd = "frida -n $packageName -l ${scriptFile.absolutePath} -H 127.0.0.1"

        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            injectProcess = p
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            val errReader = BufferedReader(InputStreamReader(p.errorStream))

            var line: String?
            while (reader.readLine().also { line = it } != null && isRunning) {
                sendLog(line ?: "")
            }
            while (errReader.readLine().also { line = it } != null && isRunning) {
                sendLog("[ERR] ${line ?: ""}")
            }
        } catch (e: Exception) {
            sendLog("[ERROR] Script failed: ${e.message}")
        } finally {
            isRunning = false
            sendLog("[INFO] Script session ended.")
        }
    }

    // ─── IL2CPP Dump ──────────────────────────────────────────

    suspend fun startDump(
        packageName: String,
        libName: String,
        onProgress: (Int) -> Unit
    ) = withContext(Dispatchers.IO) {
        if (isRunning) {
            sendLog("[WARN] Already running, stop first.")
            return@withContext
        }
        sendLog("[INFO] Starting IL2CPP dump → $packageName")
        sendLog("[INFO] Library: $libName")

        val serverOk = startFridaServer()
        if (!serverOk) {
            sendLog("[ERROR] Could not start frida-server")
            return@withContext
        }

        isRunning = true
        onProgress(5)

        // Load f_script from assets, inject placeholders
        val scriptTemplate = appContext.assets.open("f_script")
            .bufferedReader().readText()
        val finalScript = scriptTemplate
            .replace("PLACEHOLDER_PACKAGE_NAME", packageName)
            .replace("PLACEHOLDER_LIB_NAME", libName)

        val scriptFile = File(appContext.cacheDir, "evo_dump.js")
        scriptFile.writeText(finalScript)
        onProgress(15)

        val cmd = "frida -n $packageName -l ${scriptFile.absolutePath} -H 127.0.0.1"
        sendLog("[INFO] Injecting dump script…")

        try {
            val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
            injectProcess = p
            val reader = BufferedReader(InputStreamReader(p.inputStream))
            val errReader = BufferedReader(InputStreamReader(p.errorStream))
            var progress = 15
            var line: String?

            while (reader.readLine().also { line = it } != null && isRunning) {
                val l = line ?: ""
                sendLog(l)
                // Progress heuristics from script output
                when {
                    l.contains("Domain found") -> { progress = 25; onProgress(progress) }
                    l.contains("assemblies found") -> { progress = 35; onProgress(progress) }
                    l.contains("Dumping assembly") -> {
                        progress = (progress + 2).coerceAtMost(85)
                        onProgress(progress)
                    }
                    l.contains("Dump complete") || l.contains("dump.cs") -> {
                        onProgress(100)
                        sendLog("[SUCCESS] Dump saved!")
                    }
                }
            }
            while (errReader.readLine().also { line = it } != null && isRunning) {
                sendLog("[ERR] ${line ?: ""}")
            }
        } catch (e: Exception) {
            sendLog("[ERROR] Dump failed: ${e.message}")
        } finally {
            isRunning = false
            sendLog("[INFO] Dump session ended.")
        }
    }

    // ─── Stop ─────────────────────────────────────────────────

    fun stopInjection() {
        isRunning = false
        injectProcess?.destroy()
        injectProcess = null
        sendLog("[INFO] Stopped.")
    }

    // ─── Process list ─────────────────────────────────────────

    suspend fun getRunningProcesses(): List<ProcessItem> = withContext(Dispatchers.IO) {
        val result = mutableListOf<ProcessItem>()
        val pm = appContext.packageManager

        try {
            val procDir = File("/proc")
            procDir.listFiles()?.forEach { pidDir ->
                val pid = pidDir.name.toIntOrNull() ?: return@forEach
                try {
                    val cmdline = File(pidDir, "cmdline").readText()
                        .replace('\u0000', ' ').trim()
                    if (cmdline.isBlank()) return@forEach

                    val pkgName = cmdline.split(" ").firstOrNull()?.trim() ?: return@forEach
                    val appName = try {
                        val appInfo = pm.getApplicationInfo(pkgName, 0)
                        pm.getApplicationLabel(appInfo).toString()
                    } catch (e: PackageManager.NameNotFoundException) {
                        pkgName.substringAfterLast(".")
                    }
                    val icon: Drawable? = try {
                        pm.getApplicationIcon(pkgName)
                    } catch (e: Exception) { null }

                    result.add(ProcessItem(appName, pkgName, pid, icon))
                } catch (e: Exception) { /* skip inaccessible */ }
            }
        } catch (e: Exception) {
            sendLog("[ERROR] Could not list processes: ${e.message}")
        }

        return@withContext result.distinctBy { it.packageName }.sortedBy { it.name }
    }

    // ─── Installed apps ───────────────────────────────────────

    suspend fun getInstalledApps(): List<ProcessItem> = withContext(Dispatchers.IO) {
        val pm = appContext.packageManager
        val flags = PackageManager.GET_META_DATA
        return@withContext pm.getInstalledApplications(flags)
            .filter { it.flags and ApplicationInfo.FLAG_SYSTEM == 0 }
            .map {
                ProcessItem(
                    name = pm.getApplicationLabel(it).toString(),
                    packageName = it.packageName,
                    pid = 0,
                    icon = try { pm.getApplicationIcon(it.packageName) } catch (e: Exception) { null }
                )
            }.sortedBy { it.name }
    }

    // ─── Detect libraries ─────────────────────────────────────

    suspend fun detectLibraries(packageName: String): List<String> = withContext(Dispatchers.IO) {
        val libs = mutableListOf<String>()
        try {
            // Find PID for the package
            val pidResult = executeRootCommand("pgrep -f $packageName")
            val pid = pidResult.trim().lines().firstOrNull()?.trim()?.toIntOrNull()
                ?: return@withContext libs

            // Read maps
            val maps = executeRootCommand("cat /proc/$pid/maps")
            maps.lines().forEach { line ->
                if (line.contains(".so")) {
                    val soMatch = Regex("""(/[^\s]+\.so[^\s]*)""").find(line)
                    soMatch?.value?.let { path ->
                        val name = path.substringAfterLast("/")
                        if (!libs.contains(name)) libs.add(name)
                    }
                }
            }
        } catch (e: Exception) {
            sendLog("[ERROR] Library detect: ${e.message}")
        }
        return@withContext libs.sorted()
    }

    // ─── Script import ────────────────────────────────────────

    fun setImportedScript(code: String) { importedScriptCode = code }
    fun getImportedScript(): String? = importedScriptCode
    fun isRunning() = isRunning
}
