package com.fridaevo.android

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle

class ScriptPickerActivity : Activity() {

    companion object {
        const val EXTRA_SCRIPT_CODE = "script_code"
        const val EXTRA_SCRIPT_NAME = "script_name"
        private const val REQUEST_OPEN_FILE = 1001
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
            type = "*/*"
            addCategory(Intent.CATEGORY_OPENABLE)
            putExtra(Intent.EXTRA_MIME_TYPES, arrayOf("application/javascript", "text/plain", "text/javascript"))
        }
        startActivityForResult(Intent.createChooser(intent, "Select .js script"), REQUEST_OPEN_FILE)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_OPEN_FILE && resultCode == RESULT_OK) {
            data?.data?.let { uri -> readScript(uri) } ?: finish()
        } else {
            setResult(RESULT_CANCELED)
            finish()
        }
    }

    private fun readScript(uri: Uri) {
        try {
            val code = contentResolver.openInputStream(uri)
                ?.bufferedReader()?.readText() ?: ""
            val name = uri.lastPathSegment ?: "script.js"
            val result = Intent().apply {
                putExtra(EXTRA_SCRIPT_CODE, code)
                putExtra(EXTRA_SCRIPT_NAME, name)
            }
            setResult(RESULT_OK, result)
        } catch (e: Exception) {
            setResult(RESULT_CANCELED)
        } finally {
            finish()
        }
    }
}
