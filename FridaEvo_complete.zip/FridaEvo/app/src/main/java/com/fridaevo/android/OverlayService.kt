package com.fridaevo.android

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.IBinder
import android.view.GestureDetector
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewFlipper
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ScrollView
import android.widget.TextView
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private var isMinimized = false
    private val scope = CoroutineScope(Dispatchers.Main)

    // Window params
    private val params by lazy {
        WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            x = 0
            y = 200
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager

        overlayView = LayoutInflater.from(this)
            .inflate(R.layout.layout_overlay, null)

        setupOverlayViews()
        setupDrag()

        windowManager.addView(overlayView, params)
    }

    private fun setupOverlayViews() {
        val flipper = overlayView.findViewById<ViewFlipper>(R.id.ovViewFlipper)
        val tabInject = overlayView.findViewById<TextView>(R.id.ovTabInject)
        val tabScript = overlayView.findViewById<TextView>(R.id.ovTabScript)
        val tabDumper = overlayView.findViewById<TextView>(R.id.ovTabDumper)
        val btnClose = overlayView.findViewById<ImageButton>(R.id.btnOverlayClose)
        val btnMinimize = overlayView.findViewById<ImageButton>(R.id.btnOverlayMinimize)
        val tvLogs = overlayView.findViewById<TextView>(R.id.ovTvLogs)

        // Log listener
        val logListener: (String) -> Unit = { msg ->
            scope.launch {
                val current = tvLogs.text.toString()
                tvLogs.text = "$current\n$msg"
                overlayView.findViewById<ScrollView?>(tvLogs.parent as? ScrollView ?: return@launch)
                    ?.fullScroll(View.FOCUS_DOWN)
            }
        }
        FridaEngine.addLogListener(logListener)

        // Tabs
        fun selectTab(index: Int) {
            flipper.displayedChild = index
            val tabs = listOf(tabInject, tabScript, tabDumper)
            tabs.forEachIndexed { i, tab ->
                if (i == index) {
                    tab.setBackgroundResource(R.drawable.bg_tab_selected)
                    tab.setTextColor(getColor(R.color.evo_white))
                } else {
                    tab.setBackgroundColor(0)
                    tab.setTextColor(getColor(R.color.evo_tab_unselected))
                }
            }
        }
        tabInject.setOnClickListener { selectTab(0) }
        tabScript.setOnClickListener { selectTab(1) }
        tabDumper.setOnClickListener { selectTab(2) }

        // Close
        btnClose.setOnClickListener { stopSelf() }

        // Minimize: toggle content visibility
        btnMinimize.setOnClickListener {
            isMinimized = !isMinimized
            flipper.visibility = if (isMinimized) View.GONE else View.VISIBLE
            overlayView.findViewById<View>(R.id.ovTabInject).parent.let {
                (it as? View)?.visibility = if (isMinimized) View.GONE else View.VISIBLE
            }
        }

        // Inject button
        overlayView.findViewById<Button>(R.id.ovBtnStartInject).setOnClickListener {
            val pkg = overlayView.findViewById<EditText>(R.id.ovEtPackage).text.toString()
            val lib = overlayView.findViewById<EditText>(R.id.ovEtLib).text.toString()
            if (pkg.isBlank()) return@setOnClickListener
            if (FridaEngine.isRunning()) {
                FridaEngine.stopInjection()
            } else {
                scope.launch(Dispatchers.IO) {
                    FridaEngine.startFridaInject(pkg, lib, false)
                }
            }
        }

        // Script button
        overlayView.findViewById<Button>(R.id.ovBtnRunScript).setOnClickListener {
            val code = overlayView.findViewById<EditText>(R.id.ovEtScript).text.toString()
            val pkg = overlayView.findViewById<EditText>(R.id.ovEtPackage).text.toString()
            if (code.isBlank() || pkg.isBlank()) return@setOnClickListener
            if (FridaEngine.isRunning()) {
                FridaEngine.stopInjection()
            } else {
                scope.launch(Dispatchers.IO) {
                    FridaEngine.startFridaScript(pkg, code)
                }
            }
        }

        // Dump button
        overlayView.findViewById<Button>(R.id.ovBtnStartDump).setOnClickListener {
            val pkg = overlayView.findViewById<EditText>(R.id.ovEtDumperPkg).text.toString()
            val lib = overlayView.findViewById<EditText>(R.id.ovEtDumperLib).text.toString()
            if (pkg.isBlank()) return@setOnClickListener
            scope.launch(Dispatchers.IO) {
                FridaEngine.startDump(pkg, lib) {}
            }
        }
    }

    private fun setupDrag() {
        val header = overlayView.findViewById<View>(R.id.overlayHeader)
        var startX = 0f; var startY = 0f
        var initialX = 0; var initialY = 0

        header.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = event.rawX; startY = event.rawY
                    initialX = params.x; initialY = params.y
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - startX).toInt()
                    params.y = initialY + (event.rawY - startY).toInt()
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }
}
