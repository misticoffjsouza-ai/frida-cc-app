package com.fridaevo.android

import android.app.AlertDialog
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.view.ViewFlipper
import android.widget.Button
import android.widget.EditText
import android.widget.ImageButton
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.switchmaterial.SwitchMaterial
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private val scope = CoroutineScope(Dispatchers.Main)

    // ─── Tab refs ──────────────────────────────────────────────
    private lateinit var tabInject: TextView
    private lateinit var tabScript: TextView
    private lateinit var tabDumper: TextView
    private lateinit var viewFlipper: ViewFlipper

    // ─── Header ───────────────────────────────────────────────
    private lateinit var tvRootStatus: TextView
    private lateinit var btnToggleOverlay: ImageButton

    // ─── Inject tab ───────────────────────────────────────────
    private lateinit var etInjectPackage: EditText
    private lateinit var etInjectLib: EditText
    private lateinit var btnStartInject: Button
    private lateinit var btnSelectInjectProcess: Button
    private lateinit var btnSelectInjectLib: Button
    private lateinit var btnClearInjectLogs: Button
    private lateinit var swInjectSpawn: SwitchMaterial
    private lateinit var tvInjectLogs: TextView
    private lateinit var scrollInjectLogs: ScrollView

    // ─── Script tab ───────────────────────────────────────────
    private lateinit var tvScriptProcess: TextView
    private lateinit var btnSelectScriptProcess: Button
    private lateinit var etScriptCode: EditText
    private lateinit var btnRunScript: Button
    private lateinit var btnImportScript: Button
    private lateinit var btnClearScriptLogs: Button
    private lateinit var tvScriptLogs: TextView
    private lateinit var tvScriptFileName: TextView
    private lateinit var scrollScriptLogs: ScrollView

    // ─── Dumper tab ───────────────────────────────────────────
    private lateinit var etDumperPackage: EditText
    private lateinit var etDumperLib: EditText
    private lateinit var btnStartDumper: Button
    private lateinit var btnSelectDumperProcess: Button
    private lateinit var btnSelectDumperLib: Button
    private lateinit var btnClearDumperLogs: Button
    private lateinit var tvDumperLogs: TextView
    private lateinit var scrollDumperLogs: ScrollView
    private lateinit var layoutDumperProgress: View
    private lateinit var progressDumper: ProgressBar
    private lateinit var tvDumperProgressLabel: TextView

    // ─── State ────────────────────────────────────────────────
    private var selectedScriptProcess: ProcessItem? = null
    private var injectActive = false
    private var scriptActive = false

    // ─── Script picker launcher ───────────────────────────────
    private val pickScriptLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val code = result.data?.getStringExtra(ScriptPickerActivity.EXTRA_SCRIPT_CODE) ?: return@registerForActivityResult
            val name = result.data?.getStringExtra(ScriptPickerActivity.EXTRA_SCRIPT_NAME) ?: "script.js"
            etScriptCode.setText(code)
            tvScriptFileName.text = name
            FridaEngine.setImportedScript(code)
            appendScriptLog("[INFO] Imported: $name (${code.length} chars)")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        FridaEngine.init(this)
        bindViews()
        setupTabs()
        setupLogListeners()
        setupInjectTab()
        setupScriptTab()
        setupDumperTab()
        setupOverlayButton()
        checkRootAndInit()
    }

    // ─── View binding (manual) ────────────────────────────────

    private fun bindViews() {
        tvRootStatus = findViewById(R.id.tvRootStatus)
        btnToggleOverlay = findViewById(R.id.btnToggleOverlay)
        viewFlipper = findViewById(R.id.viewFlipper)
        tabInject = findViewById(R.id.tabInject)
        tabScript = findViewById(R.id.tabScript)
        tabDumper = findViewById(R.id.tabDumper)

        // Inject
        etInjectPackage = findViewById(R.id.etInjectPackage)
        etInjectLib = findViewById(R.id.etInjectLib)
        btnStartInject = findViewById(R.id.btnStartInject)
        btnSelectInjectProcess = findViewById(R.id.btnSelectInjectProcess)
        btnSelectInjectLib = findViewById(R.id.btnSelectInjectLib)
        btnClearInjectLogs = findViewById(R.id.btnClearInjectLogs)
        swInjectSpawn = findViewById(R.id.swInjectSpawn)
        tvInjectLogs = findViewById(R.id.tvInjectLogs)
        scrollInjectLogs = findViewById(R.id.scrollInjectLogs)

        // Script
        tvScriptProcess = findViewById(R.id.tvScriptProcess)
        btnSelectScriptProcess = findViewById(R.id.btnSelectScriptProcess)
        etScriptCode = findViewById(R.id.etScriptCode)
        btnRunScript = findViewById(R.id.btnRunScript)
        btnImportScript = findViewById(R.id.btnImportScript)
        btnClearScriptLogs = findViewById(R.id.btnClearScriptLogs)
        tvScriptLogs = findViewById(R.id.tvScriptLogs)
        tvScriptFileName = findViewById(R.id.tvScriptFileName)
        scrollScriptLogs = findViewById(R.id.scrollScriptLogs)

        // Dumper
        etDumperPackage = findViewById(R.id.etDumperPackage)
        etDumperLib = findViewById(R.id.etDumperLib)
        btnStartDumper = findViewById(R.id.btnStartDumper)
        btnSelectDumperProcess = findViewById(R.id.btnSelectDumperProcess)
        btnSelectDumperLib = findViewById(R.id.btnSelectDumperLib)
        btnClearDumperLogs = findViewById(R.id.btnClearDumperLogs)
        tvDumperLogs = findViewById(R.id.tvDumperLogs)
        scrollDumperLogs = findViewById(R.id.scrollDumperLogs)
        layoutDumperProgress = findViewById(R.id.layoutDumperProgress)
        progressDumper = findViewById(R.id.progressDumper)
        tvDumperProgressLabel = findViewById(R.id.tvDumperProgressLabel)
    }

    // ─── Tabs ─────────────────────────────────────────────────

    private fun setupTabs() {
        fun selectTab(index: Int) {
            viewFlipper.displayedChild = index
            val tabs = listOf(tabInject, tabScript, tabDumper)
            tabs.forEachIndexed { i, tab ->
                if (i == index) {
                    tab.setBackgroundResource(R.drawable.bg_tab_selected)
                    tab.setTextColor(getColor(R.color.evo_white))
                } else {
                    tab.setBackgroundColor(0)
                    tab.setTextColor(getColor(R.color.evo_tab_unselected))
                }
            }
        }
        tabInject.setOnClickListener { selectTab(0) }
        tabScript.setOnClickListener { selectTab(1) }
        tabDumper.setOnClickListener { selectTab(2) }
    }

    // ─── Log listeners ────────────────────────────────────────

    private fun setupLogListeners() {
        FridaEngine.addLogListener { msg ->
            runOnUiThread {
                // Route to whichever tab is active
                when (viewFlipper.displayedChild) {
                    0 -> appendInjectLog(msg)
                    1 -> appendScriptLog(msg)
                    2 -> appendDumperLog(msg)
                }
            }
        }
    }

    // ─── Root check ───────────────────────────────────────────

    private fun checkRootAndInit() {
        tvRootStatus.text = "Checking root…"
        scope.launch {
            val hasRoot = FridaEngine.checkRoot()
            tvRootStatus.text = if (hasRoot) "● ROOT" else "✕ NO ROOT"
            tvRootStatus.setTextColor(
                if (hasRoot) getColor(R.color.evo_success)
                else getColor(R.color.evo_error)
            )
        }
    }

    // ─── Inject tab ───────────────────────────────────────────

    private fun setupInjectTab() {
        btnSelectInjectProcess.setOnClickListener {
            showProcessPicker { proc ->
                etInjectPackage.setText(proc.packageName)
                appendInjectLog("[INFO] Selected: ${proc.name} (${proc.packageName})")
            }
        }

        btnSelectInjectLib.setOnClickListener {
            val pkg = etInjectPackage.text.toString()
            if (pkg.isBlank()) {
                appendInjectLog("[WARN] Enter package name first.")
                return@setOnClickListener
            }
            showLibPicker(pkg) { lib ->
                etInjectLib.setText(lib)
                appendInjectLog("[INFO] Library: $lib")
            }
        }

        btnStartInject.setOnClickListener {
            if (injectActive) {
                FridaEngine.stopInjection()
                injectActive = false
                btnStartInject.text = getString(R.string.btn_start_inject)
                btnStartInject.setBackgroundResource(R.drawable.bg_button_primary)
                return@setOnClickListener
            }
            val pkg = etInjectPackage.text.toString().trim()
            val lib = etInjectLib.text.toString().trim()
            if (pkg.isBlank()) { appendInjectLog("[WARN] Package name required."); return@setOnClickListener }

            injectActive = true
            btnStartInject.text = getString(R.string.btn_stop_inject)
            btnStartInject.setBackgroundResource(R.drawable.bg_button_danger)

            scope.launch(Dispatchers.IO) {
                FridaEngine.startFridaInject(pkg, lib, swInjectSpawn.isChecked)
                withContext(Dispatchers.Main) {
                    injectActive = false
                    btnStartInject.text = getString(R.string.btn_start_inject)
                    btnStartInject.setBackgroundResource(R.drawable.bg_button_primary)
                }
            }
        }

        btnClearInjectLogs.setOnClickListener { tvInjectLogs.text = "" }
    }

    // ─── Script tab ───────────────────────────────────────────

    private fun setupScriptTab() {
        btnSelectScriptProcess.setOnClickListener {
            showProcessPicker { proc ->
                selectedScriptProcess = proc
                tvScriptProcess.text = "${proc.name} · ${proc.packageName}"
                tvScriptProcess.setTextColor(getColor(R.color.evo_purple_light))
            }
        }

        btnImportScript.setOnClickListener {
            pickScriptLauncher.launch(Intent(this, ScriptPickerActivity::class.java))
        }

        btnRunScript.setOnClickListener {
            if (scriptActive) {
                FridaEngine.stopInjection()
                scriptActive = false
                btnRunScript.text = getString(R.string.btn_run_script)
                btnRunScript.setBackgroundResource(R.drawable.bg_button_primary)
                return@setOnClickListener
            }
            val code = etScriptCode.text.toString()
            val proc = selectedScriptProcess
            if (code.isBlank()) { appendScriptLog("[WARN] Script is empty."); return@setOnClickListener }
            if (proc == null) { appendScriptLog("[WARN] Select a process first."); return@setOnClickListener }

            scriptActive = true
            btnRunScript.text = getString(R.string.btn_stop_script)
            btnRunScript.setBackgroundResource(R.drawable.bg_button_danger)

            scope.launch(Dispatchers.IO) {
                FridaEngine.startFridaScript(proc.packageName, code)
                withContext(Dispatchers.Main) {
                    scriptActive = false
                    btnRunScript.text = getString(R.string.btn_run_script)
                    btnRunScript.setBackgroundResource(R.drawable.bg_button_primary)
                }
            }
        }

        btnClearScriptLogs.setOnClickListener { tvScriptLogs.text = "" }
    }

    // ─── Dumper tab ───────────────────────────────────────────

    private fun setupDumperTab() {
        btnSelectDumperProcess.setOnClickListener {
            showInstalledAppPicker { app ->
                etDumperPackage.setText(app.packageName)
                appendDumperLog("[INFO] Target: ${app.name} (${app.packageName})")
            }
        }

        btnSelectDumperLib.setOnClickListener {
            val pkg = etDumperPackage.text.toString().trim()
            if (pkg.isBlank()) { appendDumperLog("[WARN] Enter package name first."); return@setOnClickListener }
            appendDumperLog("[INFO] Scanning libraries…")
            scope.launch {
                val libs = withContext(Dispatchers.IO) { FridaEngine.detectLibraries(pkg) }
                if (libs.isEmpty()) {
                    appendDumperLog("[WARN] No libraries found (is the app running?)")
                    return@launch
                }
                showStringPicker("Select Library", libs) { lib ->
                    etDumperLib.setText(lib)
                    appendDumperLog("[INFO] Selected: $lib")
                }
            }
        }

        btnStartDumper.setOnClickListener {
            if (FridaEngine.isRunning()) {
                FridaEngine.stopInjection()
                btnStartDumper.text = "START DUMP"
                btnStartDumper.setBackgroundResource(R.drawable.bg_button_primary)
                layoutDumperProgress.visibility = View.GONE
                return@setOnClickListener
            }
            val pkg = etDumperPackage.text.toString().trim()
            val lib = etDumperLib.text.toString().trim()
            if (pkg.isBlank()) { appendDumperLog("[WARN] Package required."); return@setOnClickListener }

            layoutDumperProgress.visibility = View.VISIBLE
            progressDumper.progress = 0
            btnStartDumper.text = "STOP DUMP"
            btnStartDumper.setBackgroundResource(R.drawable.bg_button_danger)

            scope.launch(Dispatchers.IO) {
                FridaEngine.startDump(pkg, lib) { progress ->
                    scope.launch {
                        progressDumper.progress = progress
                        tvDumperProgressLabel.text = when {
                            progress < 20 -> "Starting Frida server…"
                            progress < 40 -> "Attached — finding IL2CPP domain…"
                            progress < 80 -> "Dumping assemblies…"
                            progress >= 100 -> "Dump complete!"
                            else -> "Dumping classes…"
                        }
                    }
                }
                withContext(Dispatchers.Main) {
                    btnStartDumper.text = "START DUMP"
                    btnStartDumper.setBackgroundResource(R.drawable.bg_button_primary)
                }
            }
        }

        btnClearDumperLogs.setOnClickListener {
            tvDumperLogs.text = ""
            layoutDumperProgress.visibility = View.GONE
        }
    }

    // ─── Overlay button ───────────────────────────────────────

    private fun setupOverlayButton() {
        btnToggleOverlay.setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                return@setOnClickListener
            }
            startService(Intent(this, OverlayService::class.java))
        }
    }

    // ─── Pickers ──────────────────────────────────────────────

    private fun showProcessPicker(onSelected: (ProcessItem) -> Unit) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_picker, null)
        val rvList = dialogView.findViewById<RecyclerView>(R.id.rvPickerList)
        val etSearch = dialogView.findViewById<EditText>(R.id.etPickerSearch)
        val progress = dialogView.findViewById<ProgressBar>(R.id.progressPicker)

        val adapter = ProcessAdapter(emptyList()) { item ->
            onSelected(item)
        }
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        val dialog = AlertDialog.Builder(this, R.style.EvoDialog)
            .setTitle(R.string.select_process_title)
            .setView(dialogView)
            .setNegativeButton("Cancel", null)
            .create()

        etSearch.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { adapter.filter(s.toString()) }
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        })

        // Override item click to dismiss dialog
        val adapterWithDismiss = ProcessAdapter(emptyList()) { item ->
            dialog.dismiss()
            onSelected(item)
        }
        rvList.adapter = adapterWithDismiss

        progress.visibility = View.VISIBLE
        scope.launch {
            val procs = withContext(Dispatchers.IO) { FridaEngine.getRunningProcesses() }
            progress.visibility = View.GONE
            adapterWithDismiss.update(procs)
            etSearch.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { adapterWithDismiss.filter(s.toString()) }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }

        dialog.show()
    }

    private fun showInstalledAppPicker(onSelected: (ProcessItem) -> Unit) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_picker, null)
        val rvList = dialogView.findViewById<RecyclerView>(R.id.rvPickerList)
        val etSearch = dialogView.findViewById<EditText>(R.id.etPickerSearch)
        val progress = dialogView.findViewById<ProgressBar>(R.id.progressPicker)

        val dialog = AlertDialog.Builder(this, R.style.EvoDialog)
            .setTitle(R.string.select_app_spawn)
            .setView(dialogView)
            .setNegativeButton("Cancel", null)
            .create()

        val adapter = ProcessAdapter(emptyList()) { item ->
            dialog.dismiss()
            onSelected(item)
        }
        rvList.layoutManager = LinearLayoutManager(this)
        rvList.adapter = adapter

        progress.visibility = View.VISIBLE
        scope.launch {
            val apps = withContext(Dispatchers.IO) { FridaEngine.getInstalledApps() }
            progress.visibility = View.GONE
            adapter.update(apps)
            etSearch.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) { adapter.filter(s.toString()) }
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
        }

        dialog.show()
    }

    private fun showLibPicker(packageName: String, onSelected: (String) -> Unit) {
        scope.launch {
            val libs = withContext(Dispatchers.IO) { FridaEngine.detectLibraries(packageName) }
            if (libs.isEmpty()) {
                appendInjectLog("[WARN] No libraries found. Is the app running?")
                return@launch
            }
            showStringPicker("Select Library (.so)", libs, onSelected)
        }
    }

    private fun showStringPicker(title: String, items: List<String>, onSelected: (String) -> Unit) {
        AlertDialog.Builder(this, R.style.EvoDialog)
            .setTitle(title)
            .setItems(items.toTypedArray()) { _, which -> onSelected(items[which]) }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ─── Log helpers ──────────────────────────────────────────

    private fun appendInjectLog(msg: String) {
        val current = tvInjectLogs.text.toString()
        tvInjectLogs.text = if (current.isEmpty()) msg else "$current\n$msg"
        scrollInjectLogs.post { scrollInjectLogs.fullScroll(View.FOCUS_DOWN) }
    }

    private fun appendScriptLog(msg: String) {
        val current = tvScriptLogs.text.toString()
        tvScriptLogs.text = if (current.isEmpty()) msg else "$current\n$msg"
        scrollScriptLogs.post { scrollScriptLogs.fullScroll(View.FOCUS_DOWN) }
    }

    private fun appendDumperLog(msg: String) {
        val current = tvDumperLogs.text.toString()
        tvDumperLogs.text = if (current.isEmpty()) msg else "$current\n$msg"
        scrollDumperLogs.post { scrollDumperLogs.fullScroll(View.FOCUS_DOWN) }
    }

    override fun onDestroy() {
        super.onDestroy()
        FridaEngine.stopInjection()
    }
}
