package com.fridaevo.android

import android.graphics.drawable.Drawable

data class ProcessItem(
    val name: String,
    val packageName: String,
    val pid: Int,
    val icon: Drawable? = null
)
