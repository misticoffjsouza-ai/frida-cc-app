# FRIDA EVO

Android reverse engineering tool with Frida injection UI.
Dark purple/blue theme.

## What was completed

- Project structure cleaned (removed broken `{java` folders)
- `assets/f_engine` → frida-server 17.26.3 android-arm64
- `assets/f_script` → basic IL2CPP dump script
- Adaptive launcher icons (mipmap-anydpi-v26)
- Manifest tools namespace fixed
- Gradle wrapper properties added

## Requirements to build

- Android Studio Hedgehog+ or command-line SDK
- JDK 17
- Android SDK 34
- Rooted device for runtime (Magisk recommended)

## Build

```bash
cd FridaEvo
# set sdk.dir in local.properties
./gradlew assembleDebug
```

APK output:
`app/build/outputs/apk/debug/app-debug.apk`

## Runtime

1. Install APK
2. Grant Overlay + Storage permissions
3. Grant root when asked
4. Use INJECT / SCRIPT / DUMPER tabs or floating overlay

## Notes

- f_engine is ~85MB (frida-server). Final APK will be large.
- For production, consider downloading frida-server on first run instead of embedding.
